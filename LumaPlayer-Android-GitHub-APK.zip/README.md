# Luma Player

Reproductor Android local, moderno y sin anuncios para música y videos MP4.

## Incluye

- Reproducción en segundo plano y con el teléfono bloqueado.
- Controles desde la notificación y pantalla de bloqueo.
- Selector de archivos del sistema para elegir audio y MP4.
- Cola de reproducción y barra de reproducción rápida.
- Diseño oscuro moderno, pensado para ampliar con favoritos, playlists y ecualizador.
- Media3/ExoPlayer para formatos compatibles con Android: MP3, M4A/AAC, WAV, FLAC, OGG y MP4 según el códec.

## Abrir y compilar

Abrir la carpeta en Android Studio Ladybug o una versión posterior y ejecutar la configuración `app` en un teléfono Android 8.0 o superior.

También se puede compilar automáticamente desde GitHub: subir este proyecto a un repositorio, abrir la pestaña **Actions**, ejecutar **Construir APK de Luma Player** y descargar el artefacto `LumaPlayer-debug-apk`.

La app no necesita internet para reproducir los archivos guardados en el teléfono.
