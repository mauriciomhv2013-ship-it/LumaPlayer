package com.lumaplayer.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

class DownloadActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DownloadPage() }
    }

    @Composable
    private fun DownloadPage() {
        Surface(modifier = Modifier.fillMaxSize()) {
            AndroidView(factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.userAgentString = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"
                    CookieManager.getInstance().setAcceptCookie(true)
                    webViewClient = WebViewClient()
                    webChromeClient = WebChromeClient()
                    setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
                        enqueueDownload(context, url, userAgent, contentDisposition, mimetype)
                    })
                    loadUrl("https://y2mate.gs/es/")
                }
            }, modifier = Modifier.fillMaxSize())
        }
    }

    private fun enqueueDownload(context: Context, url: String, userAgent: String, contentDisposition: String, mimeType: String) {
        val request = DownloadManager.Request(Uri.parse(url)).apply {
            setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
            setDescription("Descargando en Luma Player")
            setMimeType(mimeType)
            addRequestHeader("User-Agent", userAgent)
            addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalFilesDir(context, Environment.DIRECTORY_MUSIC, "Luma Player")
        }
        (context.getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
    }
}
