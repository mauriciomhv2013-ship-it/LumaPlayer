package com.lumaplayer.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

private val Ink = Color(0xFF0B0B10)
private val Purple = Color(0xFF9B6CFF)
private val Surface = Color(0xFF17171F)

class MainActivity : ComponentActivity() {
    private lateinit var controllerFuture: ListenableFuture<MediaController>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        controllerFuture = MediaController.Builder(this, SessionToken(this, androidx.media3.session.MediaSessionService::class.java)).buildAsync()
        setContent { LumaTheme { LumaApp(controllerFuture) } }
    }

    override fun onDestroy() {
        MediaController.releaseFuture(controllerFuture)
        super.onDestroy()
    }
}

@Composable
private fun LumaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Ink, surface = Surface), content = content)
}

@Composable
private fun LumaApp(controllerFuture: ListenableFuture<MediaController>) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var tracks by remember { mutableStateOf(scanManagedDownloads(context)) }
    var selectedTab by remember { mutableIntStateOf(0) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val incoming = uris.map { uri ->
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            Track(uri, uri.lastPathSegment?.substringAfterLast('/') ?: "Archivo")
        }
        tracks = (tracks + incoming).distinctBy { it.uri }
        if (incoming.isNotEmpty()) {
            val c = controllerFuture.get()
            c.setMediaItems(incoming.map { MediaItem.fromUri(it.uri) })
            c.prepare(); c.play()
        }
    }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    DisposableEffect(Unit) {
        onDispose { }
    }

    Scaffold(containerColor = Ink, bottomBar = {
        NavigationBar(containerColor = Ink) {
            listOf(Icons.Default.Home to "Inicio", Icons.Default.LibraryMusic to "Biblioteca", Icons.Default.FavoriteBorder to "Favoritos").forEachIndexed { index, item ->
                NavigationBarItem(selected = selectedTab == index, onClick = { selectedTab = index }, icon = { Icon(item.first, null) }, label = { Text(item.second) })
            }
        }
    }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column { Text("Luma", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold); Text("Tu música, a tu manera", color = Color.Gray) }
                    IconButton(onClick = { picker.launch(arrayOf("audio/*", "video/mp4")) }) { Icon(Icons.Default.Add, "Agregar archivos", tint = Purple) }
                }
            }
            item {
                Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.background(Brush.linearGradient(listOf(Color(0xFF38256B), Color(0xFF151321)))).padding(22.dp)) {
                        Column { Text("Tu biblioteca", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Reproducí música y videos locales sin anuncios.", color = Color(0xFFD4C9FF), modifier = Modifier.padding(top = 6.dp)); Button(onClick = { picker.launch(arrayOf("audio/*", "video/mp4")) }, modifier = Modifier.padding(top = 16.dp)) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Elegir archivos") } }
                    }
                }
            }
            item {
                Card(onClick = { context.startActivity(Intent(context, DownloadActivity::class.java)) }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Surface), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFF2B2145)) { Icon(Icons.Default.Download, null, tint = Purple, modifier = Modifier.padding(12.dp)) }
                        Column(Modifier.padding(start = 14.dp).weight(1f)) { Text("Descargas", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Text("Abrir Y2Mate y guardar en la carpeta de Luma", color = Color.Gray, fontSize = 13.sp) }
                        Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
                    }
                }
            }
            item {
                Card(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/"))) }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Surface), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFF3A1F28)) { Icon(Icons.Default.PlayCircle, null, tint = Color(0xFFFF5A6A), modifier = Modifier.padding(12.dp)) }
                        Column(Modifier.padding(start = 14.dp).weight(1f)) { Text("YouTube", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Text("Abrir la aplicación oficial o la página web", color = Color.Gray, fontSize = 13.sp) }
                        Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
                    }
                }
            }
            item { Text(if (tracks.isEmpty()) "Todavía no agregaste archivos" else "Agregados recientemente", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            items(tracks) { track ->
                ListItem(headlineContent = { Text(track.name, color = Color.White) }, supportingContent = { Text("Archivo local", color = Color.Gray) }, leadingContent = { Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFF292337)) { Icon(Icons.Default.MusicNote, null, tint = Purple, modifier = Modifier.padding(12.dp)) } }, trailingContent = { IconButton(onClick = { val c = controllerFuture.get(); c.setMediaItem(MediaItem.fromUri(track.uri)); c.prepare(); c.play() }) { Icon(Icons.Default.PlayArrow, "Reproducir", tint = Purple) } }, colors = ListItemDefaults.colors(containerColor = Surface), modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)))
            }
            item {
                if (tracks.isNotEmpty()) PlayerBar(controllerFuture)
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

private fun scanManagedDownloads(context: android.content.Context): List<Track> {
    val folder = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)?.resolve("Luma Player") ?: return emptyList()
    if (!folder.exists()) return emptyList()
    return folder.walkTopDown().filter { it.isFile && it.length() > 0L }.map { Track(Uri.fromFile(it), it.name) }.toList()
}

@Composable
private fun PlayerBar(future: ListenableFuture<MediaController>) {
    val controller = future.get()
    val playing by remember { derivedStateOf { controller.isPlaying } }
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF292337)), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.GraphicEq, null, tint = Purple, modifier = Modifier.size(34.dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(controller.currentMediaItem?.mediaMetadata?.title ?: "Reproduciendo", color = Color.White, maxLines = 1); Text("Luma Player", color = Color.Gray, fontSize = 12.sp) }
            IconButton(onClick = { if (playing) controller.pause() else controller.play() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White) }
        }
    }
}

private data class Track(val uri: Uri, val name: String)
